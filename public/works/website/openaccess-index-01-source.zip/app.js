// 由 asm-web 生成。零依赖、零构建:直接被 <script src> 加载即可运行。
(function () {
  "use strict";
  var blocks = Array.prototype.slice.call(document.querySelectorAll("section.block"));
  var links = Array.prototype.slice.call(document.querySelectorAll(".nav-link"));
  if (!blocks.length) return;

  function markActive(id) {
    links.forEach(function (a) {
      var on = a.getAttribute("href") === "#" + id;
      if (on) a.classList.add("is-active");
      else a.classList.remove("is-active");
    });
    // 导航那一行小字不够:滚到一半时读者要在**正文里**看出自己停在哪一段。
    blocks.forEach(function (b) {
      if (b.id === id) b.classList.add("is-current");
      else b.classList.remove("is-current");
    });
  }

  if (typeof IntersectionObserver === "function") {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) markActive(e.target.id);
      });
    }, { rootMargin: "-45% 0px -45% 0px" });
    blocks.forEach(function (b) { io.observe(b); });
  } else {
    markActive(blocks[0].id);
  }

  // 目录:从内容清单渲染,清单取不到就退回从 DOM 读,两条路都不改正文。
  function renderToc(sections) {
    var main = document.querySelector(".site-main");
    if (!main || !sections.length) return;
    var box = document.createElement("aside");
    box.className = "site-toc";
    box.setAttribute("aria-label", "contents");
    var summary = document.createElement("strong");
    summary.textContent = "本页共 " + sections.length + " 个区块";
    box.appendChild(summary);
    var list = document.createElement("ol");
    sections.forEach(function (s) {
      var id = String((s && s.id) || "");
      var item = document.createElement("li");
      var link = document.createElement("a");
      link.setAttribute("href", "#" + id);
      link.textContent = String((s && (s.heading || s.id)) || "");
      item.appendChild(link);
      list.appendChild(item);
    });
    box.appendChild(list);
    main.insertBefore(box, main.firstChild);
  }

  function fromDom() {
    return blocks.map(function (b) {
      var h = b.querySelector(".block-heading");
      return { id: b.id, heading: h ? h.textContent : b.id };
    });
  }

  try {
    if (typeof fetch === "function") {
      fetch("content.json")
        .then(function (r) { return r.json(); })
        .then(function (doc) {
          var pages = (doc && doc.pages) || [];
          var sections = pages.reduce(function (acc, p) { return acc.concat(p.sections || []); }, []);
          renderToc(sections.length ? sections : fromDom());
        })
        .catch(function () { renderToc(fromDom()); });
    } else {
      renderToc(fromDom());
    }
  } catch (err) {
    renderToc(fromDom());
  }

  // ── 位置感:吸顶反馈 + 阅读进度 ────────────────────────────────────────
  var nav = document.querySelector(".site-nav");
  var root = document.documentElement;
  var bar = null;

  function makeProgress() {
    var box = document.createElement("div");
    box.className = "site-progress";
    // 纯装饰:滚动位置对读屏软件是浏览器自己的事,重复播报只会吵。
    box.setAttribute("aria-hidden", "true");
    var fill = document.createElement("span");
    box.appendChild(fill);
    document.body.appendChild(box);
    return fill;
  }

  function scrollTop() {
    return window.pageYOffset || root.scrollTop || 0;
  }

  function paint() {
    var top = scrollTop();
    if (nav) { if (top > 8) nav.classList.add("is-stuck"); else nav.classList.remove("is-stuck"); }
    if (bar) {
      var span = root.scrollHeight - window.innerHeight;
      var ratio = span > 0 ? top / span : 1;
      if (ratio < 0) ratio = 0;
      if (ratio > 1) ratio = 1;
      bar.style.transform = "scaleX(" + ratio.toFixed(4) + ")";
    }
  }

  var ticking = false;
  function schedule() {
    if (ticking) return;
    ticking = true;
    var raf = window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function (fn) { return setTimeout(fn, 16); };
    raf(function () { ticking = false; paint(); });
  }

  // 一屏就读完的页面不插进度条 —— 那种页面上它没有信息量,只是一条装饰。
  if (root.scrollHeight > window.innerHeight * 1.6) bar = makeProgress();
  window.addEventListener("scroll", schedule);
  window.addEventListener("resize", schedule);
  paint();
})();

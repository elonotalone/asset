夜间海岸观测：2026 年度影像汇报

这一份 index.html 是「网页版 PPT」这条产线的成品本体,1948262 字节,
sha256 852738ceab5a974d7d504278cc37cd5f28fe44a48c33620126b7c501449ab14b。

它是自包含的:照片以 data URI 内嵌,没有任何外部请求、外部脚本或外部样式表。
用任意浏览器打开 index.html 即可翻页(键盘左右键 / 点击左右半屏 / 触摸滑动)。

站内的在线播放入口是隔离域 *.oceanleo.app,与本站不同域,这是刻意的:
用户内容与会话域必须分开(docs/architecture/oceanleo-untrusted-content-isolation.md)。
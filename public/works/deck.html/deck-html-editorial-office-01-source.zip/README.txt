灯还亮着：120 个工位，一天里有多久是空的

这一份 index.html 是「网页版 PPT」这条产线的成品本体,737567 字节,
sha256 f0fc1b626a966c486571f92d94574eaf0207abc15a6df066f07d353b29709583。

它是自包含的:照片以 data URI 内嵌,没有任何外部请求、外部脚本或外部样式表。
用任意浏览器打开 index.html 即可翻页(键盘左右键 / 点击左右半屏 / 触摸滑动)。

站内的在线播放入口是隔离域 *.oceanleo.app,与本站不同域,这是刻意的:
用户内容与会话域必须分开(docs/architecture/oceanleo-untrusted-content-isolation.md)。